import Vue from "vue"
import Router from "vue-router"
import store from "@/store/store"

Vue.use(Router)

const requireAuth = () => (from, to, next) => {
  if (store.getters.getIsAuth) return next()
  else next("/")
}

export default new Router({
  mode: "history",
  routes: [
    {
      path: "/",
      name: "Home",
      component: () => import("@/views/Login.vue")
    },
    {
      path: "/device",
      name: "Device",
      component: () => import("@/views/Device.vue"),
      beforeEnter: requireAuth()
    }
  ]
})
