var ws = require('ws');
const Gpio = require('onoff').Gpio;
const led = new Gpio(21, 'out');

var socket = new ws("ws://localhost:8951/com.damda.sample.control_app/control");

socket.on("open", function(){
    console.log("connected");
});

socket.on("error", function(err){
   console.log("error: ", err);
});

socket.on("close", function(){
   console.log("close");
});

socket.on("message", function(data){
   console.log("data: ", data.toString());
   data = JSON.parse(data.toString());
   if (data["command"] == "ledon") {
       console.log("ledon is called")
        led.writeSync(1);
   } else if (data["command"] == "ledoff"){
       console.log("ledoff is called")
       led.writeSync(0);
   }
});

