<template>
  <div class="col-12 container">
    <img alt="Thinq logo" src="../assets/images/thinq.png"/>
    <span><strong>Example</strong></span>
    <div class="col-12 container">
      <div class="col-lg-4 col-md-6 col-xs-8" style="float: none; margin: 0 auto;">
        <b-form class="form-signin" style="text-align: center">
          <b-form-input class="form-control" v-model="email" type="text" required placeholder="Email address"/>
          <b-form-input class="form-control" v-model="password" required placeholder="Password" type="password"/>
          <b-button type="submit" variant="primary" class="btn btn-sm btn-primary" @click="onSubmit">LG Account 로그인</b-button>
        </b-form>
      </div>
    </div>
  </div>
</template>

<script>
import CryptoJS from "crypto-js"
import axios from "axios"
const uuid = require("uuid")
const clientId = ""
const clientSecret = ""

export default {
  name: "loginForm",
  data: () => ({
    email: "",
    password: ""
  }),
  methods: {
    async onSubmit(event) {
      event.preventDefault()
      let passwordInSha512 = CryptoJS.SHA512(this.password).toString(CryptoJS.enc.Hex)
      let param = {
        grant_type: 'password',
        id: this.email,
        password: passwordInSha512
      }
      await axios.post(`${process.env.VUE_APP_API_SERVER}/token`, param, {
        headers: {
          "x-country-code": 'KR',
          "x-message-id": Buffer.from(uuid.v4()).toString("base64").slice(0, 22),
          "x-client-id": clientId,
          "x-client-secret": clientSecret,
        }
      }).then(res => {
        if (res.status === 200 && !res.data.error) {
          console.log(res.data)
          let access_token = res.data.access_token
          sessionStorage.setItem('access_token', access_token)
          axios.defaults.headers.common['Authorization'] = access_token
          this.$store.dispatch('setAuth', true).then(() => {
            this.$router.push({name: "Device"})
          })
        } else {
          alert(res.data.error.message)
        }
      }).catch(() => {
        alert(`Wrong ID or password.`)
      })
    },
    onReset(event) {
      event.preventDefault()
      this.email = ""
      this.password = ""
    }
  }
};
</script>
<style scoped>
.form-signin .checkbox {
  margin-bottom: 5px;
}

.form-signin input {
  height: 32px;
}

.form-signin input[type="text"] {
  margin-bottom: -1px;
  border-bottom-left-radius: 0;
  border-bottom-right-radius: 0;
}

.form-signin input[type="password"] {
  margin-bottom: 5px;
  border-top-left-radius: 0;
  border-top-right-radius: 0;
}

.form-signin button {
  margin-left: 5px;
}
</style>
