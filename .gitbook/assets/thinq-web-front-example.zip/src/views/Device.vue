<template>
  <div class="container">
    <div style="float: none; margin: 0 auto;">
      <b-card no-body>
        <b-tabs pills card vertical>
          <b-tab title="에어컨">
            <b-card-text>
              <div class="status_panel">
                <div class="status_air_conditioner row">
                  <div class="power_control_panel">
                    <div class="btn_power_area">
                      <b-img class="btn_power" rounded="circle" @click="turnOnOff('air')" :class="[isActiveAir ? 'on' : 'off']">전원</b-img>
                    </div>
                  </div>
                  <div class="degree_air_conditioner">
                    <strong class="num_degree" :class="[isActiveAir ? 'on' : 'off']">{{ !aircon_status ? '' : aircon_status.temperature.currentTemperature }}</strong>
                    <span class="num_degree degree_unit" :class="[isActiveAir ? 'on' : 'off']">degree_c</span>
                    <div class="degree_adjust">
                      <button class="btn_degree_up" @click="tempChange('up')" :disabled="isAirDisabled" :class="[isActiveAir ? 'on' : 'off']">
                        온도 올림
                      </button>
                      <button class="btn_degree_down" @click="tempChange('down')" :disabled="isAirDisabled" :class="[isActiveAir ? 'on' : 'off']">
                        온도 내림
                      </button>
                    </div>
                  </div>
                </div>
              </div>
              <div class="set_left_bottom_panel air_conditioner">
                <ul class="prop_lists">
                  <li>
                    <span class="prop_name" :class="[isActiveAir ? 'on' : 'off']">Mode</span>
                    <span class="form_area">
                      <b-form-select
                          class="select_simulator gray"
                          @change="modeChange"
                          v-model="!aircon_status ? '' : aircon_status.airConJobMode.currentJobMode"
                          size="sm"
                          name="airState.opMode"
                          :disabled="isAirDisabled"
                          :class="[isActiveAir ? 'on' : 'off']"
                          :options="aircon_mode_option"/>
                    </span>
                  </li>
                  <li>
                    <span class="prop_name" :class="[isActiveAir ? 'on' : 'off']">Fan Speed</span>
                    <span class="form_area">
                      <b-form-select
                          class="select_simulator gray"
                          @change="fanSpeedChange"
                          v-model="!aircon_status ? '' : aircon_status.airFlow.windStrength"
                          size="sm"
                          name="airState.windStrength"
                          :disabled="isAirDisabled"
                          :class="[isActiveAir ? 'on' : 'off']"
                          :options="fan_speen_option"/>
                    </span>
                  </li>
                </ul>
              </div>
            </b-card-text>
          </b-tab>
          <b-tab title="세탁기" v-if="washer_status">
            <b-card-text>
              <div class="status_panel">
                <div class="status_washer row">
                  <div class="power_control_panel">
                    <div class="btn_power_area">
                      <b-img class="btn_power" rounded="circle" @click="turnOnOff('washer')" :class="[isActiveWasher ? 'on' : 'off']">전원</b-img>
                    </div>
                  </div>
                  <div class="degree_air_conditioner">
                    <div class="wawher_adjust" style="width:30px">
                      <button class="btn_course_start" @click="startWasher()" :disabled="isWasherDisabled" :class="[isActiveWasher ? 'on' : 'off']">
                        세탁시작
                      </button>
                    </div>
                    <strong class="num_washer" :class="[isActiveWasher ? 'on' : 'off']">{{ !washer_status.hasOwnProperty('timer') ? '00' : this.washer_status.timer.remainHour }}:{{ !washer_status.hasOwnProperty('timer') ? '00' : this.washer_status.timer.remainMinute }}</strong>
                  </div>
                </div>
                <div class="status_washer status row" :class="[isActiveWasher ? 'on' : 'off']">
                  <strong>{{ !washer_status ? '' : washer_status.runState.currentState }}</strong>
                </div>
              </div>
              <div class="set_left_bottom_panel air_conditioner">
                <ul class="prop_lists">
                  <li>
                    <span class="prop_name" :class="[isActiveWasher ? 'on' : 'off']">Course</span>
                    <span class="form_area">
                      <b-form-select
                          class="select_simulator gray"
                          @change="washerModeChange"
                          v-model="washer_course"
                          size="sm"
                          :disabled="isWasherDisabled"
                          :class="[isActiveWasher ? 'on' : 'off']"
                          :options="washer_course_option"/>
                    </span>
                  </li>
                </ul>
              </div>
            </b-card-text>
          </b-tab>
          <b-tab title="도어윈도우센서" v-if="door_status">
            <b-card-text>
              <div class="status_washer status row">
                <strong>도어윈도우센서 : {{ !door_status ? '' : door_status.runState.currentState }}</strong>
              </div>
            </b-card-text>
          </b-tab>
        </b-tabs>
      </b-card>
    </div>
    <div class="col" style="margin-top: 10px">
      <b-button @click="subscribe_event('post')">Subscribe Event</b-button>&nbsp;
      <b-button @click="unsubscribe_event('delete')">Unsubscribe Event</b-button>&nbsp;&nbsp;&nbsp;&nbsp;
      <b-button @click="subscribe_notification('post')">Subscribe Push</b-button>&nbsp;
      <b-button @click="unsubscribe_notification('delete')">Unsubscribe Push</b-button>&nbsp;
    </div>
  </div>
</template>

<script>
const uuid = require("uuid")
const clientId = ""
const clientSecret = ""

export default {
  data() {
    return {
      devices_list: [],
      device_id: {},
      device_push: null,
      device_event: null,
      washer_status: null,
      aircon_status: null,
      door_status: null,
      target_temperature: 0,
      airPowerOn: "POWER_OFF",
      washerPowerOn: "POWER_OFF",
      washer_course: "1",
      aircon_mode_option: [
        {value: "COOL", text: "Cool"},
        {value: "AIR_DRY", text: "Air Dry"},
        {value: "AIR_CLEAN", text: "Purification"}
      ],
      fan_speen_option: [
        {value: "LOW", text: "Low"},
        {value: "MID", text: "Mid"},
        {value: "HIGH", text: "High"}
      ],
      washer_course_option: [
        {value: "0", text: "Not Selected"},
        {value: "1", text: "Normal"},
        {value: "2", text: "Speed Wash"},
        {value: "3", text: "Silent"}
      ]
    }
  },
  mounted() {
    this.$axios.get(`${process.env.VUE_APP_API_SERVER}/devices`, {
      headers: {
        "x-country-code": 'KR',
        "x-message-id": Buffer.from(uuid.v4()).toString("base64").slice(0, 22),
        "x-client-id": clientId,
        "x-client-secret": clientSecret,
        "Authorization": `Bearer ${sessionStorage.getItem('access_token')}`,
        "Content-Type": "application/json"
      }
    }).then(response => {
      this.devices_list = []
      let devices = response.data.response
      this.devices_list = devices
      for (let idx in devices) {
        if (["DEVICE_AIR_CONDITIONER", "DEVICE_WASHER", "DEVICE_LUMI_DOOR_WINDOW_SENSOR"].includes(devices[idx].deviceInfo.deviceType)) {
          this.device_id[devices[idx].deviceInfo.deviceType] = devices[idx].deviceId

          this.$axios.get(`${process.env.VUE_APP_API_SERVER}/devices/${devices[idx].deviceId}`, {
            headers: {
              "x-country-code": 'KR',
              "x-message-id": Buffer.from(uuid.v4()).toString("base64").slice(0, 22),
              "x-client-id": clientId,
              "x-client-secret": clientSecret,
              "Authorization": `Bearer ${sessionStorage.getItem('access_token')}`,
              "Content-Type": "application/json"
            }
          }).then(response => {
            if (devices[idx].deviceId === this.device_id['DEVICE_AIR_CONDITIONER']) {
              this.aircon_status = response.data.response
            } else if (devices[idx].deviceId === this.device_id['DEVICE_WASHER']) {
              this.washer_status = response.data.response[0]
            } else {
              this.door_status = response.data.response
            }
          })
        }
      }
    }).catch(function (error) {
      console.log(error)
    })

    const socket_url = `${process.env.VUE_APP_SOCKET_SERVER}?access_token=${sessionStorage.getItem('access_token')}`
    const socket = new WebSocket(socket_url)

    socket.onopen = function (e) {
      console.log("websocket open")
    }

    socket.onmessage = (event) => {
      let msg = JSON.parse(event.data)
      if (msg.hasOwnProperty('push')) {
        this.device_push = msg
      } else if (msg.hasOwnProperty('event')) {
        this.device_event = msg
      } else if (msg.hasOwnProperty('pushType') && msg.pushType === 'DEVICE_PUSH') {
        this.device_push = msg
      } else if (msg.hasOwnProperty('pushType') && msg.pushType === 'DEVICE_STATUS') {
        this.device_event = {
          event: msg
        }
      }
    }

    socket.onclose = function (event) {
      if (event.wasClean) {
        console.log(`[close] connection closed (code=${event.code} reason=${event.reason})`)
      } else {
        console.log('[close] connection closed by error')
      }
    }

    socket.onerror = function (error) {
      console.log(`[error] ${error.message}`)
    }

  },
  methods: {
    turnOnOff(device) {
      if ("air" === device) {
        let payload = {
          operation: {
            airConOperationMode: this.airPowerOn ? "POWER_OFF" : "POWER_ON"
          }
        }
        this.control(this.device_id["DEVICE_AIR_CONDITIONER"], payload)
        this.airPowerOn = !this.airPowerOn
      }
      if ("washer" === device) {
        let payload = {
          operation: {
            remoteStart: "1",
            washerOperationMode: this.washerPowerOn ? "POWER_OFF" : "POWER_ON"
          }
        }
        this.control(this.device_id["DEVICE_WASHER"], payload)
        this.washerPowerOn = !this.washerPowerOn
      }
    },
    tempChange(mode) {
      if (mode === "up") {
        this.aircon_status.temperature.currentTemperature++;
        this.target_temperature = this.aircon_status.temperature.currentTemperature;
      }
      if (mode === "down") {
        this.aircon_status.temperature.currentTemperature--;
        this.target_temperature = this.aircon_status.temperature.currentTemperature;
      }
      let payload = {
        temperature: {
          targetTemperature: this.target_temperature,
          unit: "C"
        }
      }
      this.control(this.device_id["DEVICE_AIR_CONDITIONER"], payload)
    },
    modeChange() {
      let payload = {
        airConJobMode: {
          currentJobMode: this.aircon_status.airConJobMode.currentJobMode
        }
      }
      this.control(this.device_id["DEVICE_AIR_CONDITIONER"], payload)
    },
    fanSpeedChange() {
      let payload = {
        airFlow: {
          windStrength: this.aircon_status.airFlow.windStrength
        }
      }
      this.control(this.device_id["DEVICE_AIR_CONDITIONER"], payload)
    },
    startWasher() {
      this.washer_status.runState.currentState = "INITIAL"
      let payload = {
        location: {
          locationName: "MAIN"
        },
        operation: {
          washerOperationMode: "START"
        }
      };
      this.control(this.device_id["DEVICE_WASHER"], payload)
    },
    washerModeChange() {
      let operationMode = {}
      switch (this.washer_course) {
        case "0":
          operationMode = {
            soilWash: "0",
            rinse: "0",
            spin: "3",
            temp: "0",
            steam: "0",
            turboShot: "0",
            reserveTimeHour: "0",
            course: "",
            opCourse: "21",
            smartCourse: "51",
            remainTimeHour: "0",
            remainTimeMinute: "11"
          };
          break
        case "1":
          operationMode = {
            soilWash: "2",
            rinse: "2",
            spin: "4",
            temp: "3",
            steam: "0",
            turboShot: "0",
            reserveTimeHour: "0",
            course: "1",
            opCourse: "5",
            smartCourse: "0",
            remainTimeHour: "0",
            remainTimeMinute: "45"
          };
          break
        case "2":
          operationMode = {
            soilWash: "2",
            rinse: "1",
            spin: "3",
            temp: "3",
            steam: "1",
            turboShot: "0",
            reserveTimeHour: "0",
            course: "2",
            opCourse: "4",
            smartCourse: "0",
            remainTimeHour: "0",
            remainTimeMinute: "28"
          };
          break
        case "3":
          operationMode = {
            soilWash: "2",
            rinse: "4",
            spin: "2",
            temp: "3",
            steam: "0",
            turboShot: "0",
            reserveTimeHour: "0",
            course: "3",
            opCourse: "7",
            smartCourse: "0",
            remainTimeHour: "0",
            remainTimeMinute: "41"
          }
          break
      }
      let payload = {
        location: {
          locationName: "MAIN"
        },
        operation: operationMode
      }
      this.control(this.device_id["DEVICE_WASHER"], payload)
    },
    control(device_id, command) {
      const headers = {
        "x-country-code": 'KR',
        "x-message-id": Buffer.from(uuid.v4()).toString("base64").slice(0, 22),
        "x-client-id": clientId,
        "x-client-secret": clientSecret,
        "Authorization": `Bearer ${sessionStorage.getItem('access_token')}`,
        "Content-Type": "application/json"
      }
      this.$axios.post(`${process.env.VUE_APP_API_SERVER}/devices/${device_id}`, command, {
        headers: headers
      }).then(response => {
        console.log(response)
      }).catch(function (error) {
        console.log(error)
      })
    },
    async subscribe_event(method) {
      const headers = {
        "x-country-code": 'KR',
        "x-message-id": Buffer.from(uuid.v4()).toString("base64").slice(0, 22),
        "x-client-id": clientId,
        "x-client-secret": clientSecret,
        "Authorization": `Bearer ${sessionStorage.getItem('access_token')}`,
        "Content-Type": "application/json"
      }
      for (const key in this.device_id) {
        await this.$axios[method](`${process.env.VUE_APP_API_SERVER}/event/${this.device_id[key]}`, null, {
          headers: headers
        }).then(response => {
          console.log(response)
        }).catch(function (error) {
          console.log(error)
        })
      }
    },
    async unsubscribe_event(method) {
      const headers = {
        "x-country-code": 'KR',
        "x-message-id": Buffer.from(uuid.v4()).toString("base64").slice(0, 22),
        "x-client-id": clientId,
        "x-client-secret": clientSecret,
        "Authorization": `Bearer ${sessionStorage.getItem('access_token')}`,
        "Content-Type": "application/json"
      }
      for (const key in this.device_id) {
        await this.$axios[method](`${process.env.VUE_APP_API_SERVER}/event/${this.device_id[key]}`, {
          headers: headers
        }, null).then(response => {
          console.log(response)
        }).catch(function (error) {
          console.log(error)
        })
      }
    },
    async subscribe_notification(method) {
      const headers = {
        "x-country-code": 'KR',
        "x-message-id": Buffer.from(uuid.v4()).toString("base64").slice(0, 22),
        "x-client-id": clientId,
        "x-client-secret": clientSecret,
        "Authorization": `Bearer ${sessionStorage.getItem('access_token')}`,
        "Content-Type": "application/json"
      }
      for (const key in this.device_id) {
        await this.$axios[method](`${process.env.VUE_APP_API_SERVER}/push/${this.device_id[key]}`, null, {
          headers: headers
        }).then(response => {
          console.log(response)
        }).catch(function (error) {
          console.log(error)
        })
      }
    },
    async unsubscribe_notification(method) {
      const headers = {
        "x-country-code": 'KR',
        "x-message-id": Buffer.from(uuid.v4()).toString("base64").slice(0, 22),
        "x-client-id": clientId,
        "x-client-secret": clientSecret,
        "Authorization": `Bearer ${sessionStorage.getItem('access_token')}`,
        "Content-Type": "application/json"
      }
      for (const key in this.device_id) {
        await this.$axios[method](`${process.env.VUE_APP_API_SERVER}/push/${this.device_id[key]}`, {
          headers: headers
        }, null).then(response => {
          console.log(response)
        }).catch(function (error) {
          console.log(error)
        })
      }
    },
  },
  computed: {
    isActiveAir: function () {
      let airConOperationMode = 'POWER_OFF'
      if (this.aircon_status && this.aircon_status.hasOwnProperty('operation')) {
        airConOperationMode = this.aircon_status.operation.airConOperationMode
      }
      this.airPowerOn = airConOperationMode
      return airConOperationMode === 'POWER_ON'
    },
    isAirDisabled: function () {
      return this.airPowerOn === 'POWER_OFF'
    },
    isActiveWasher: function () {
      let currentState = 'POWER_OFF'
      if (this.washer_status && this.washer_status.hasOwnProperty('runState')) {
        currentState = this.washer_status.runState.currentState
      }
      this.washerPowerOn = currentState !== 'POWER_OFF' ? 'POWER_ON' : 'POWER_OFF'
      return currentState !== 'POWER_OFF';
    },
    isWasherDisabled: function () {
      return this.washerPowerOn === 'POWER_OFF'
    }
  },
  watch: {
    device_event: function (newVal) {
      if (newVal.event.deviceId === this.device_id['DEVICE_AIR_CONDITIONER']) {
        this.aircon_status = newVal.event.report;
      }
      if (newVal.event.deviceId === this.device_id['DEVICE_WASHER']) {
        this.washer_status = newVal.event.report[0];
      }
      if (newVal.event.deviceId === this.device_id['DEVICE_LUMI_DOOR_WINDOW_SENSOR']) {
        this.door_status = newVal.event.report;
      }
    },
    device_push: function (newVal) {
      let msg = ''
      if (msg.hasOwnProperty('push')) {
        msg = newVal.push
      } else {
        msg = newVal
      }
      const pushCode = msg.pushCode;
      if (pushCode !== undefined) {
        alert(pushCode)
      }
    }
  },
};
</script>
<style scoped>
.ps {
  height: 145px;
  overflow-x: hidden;
}

.container {
  font-size: 12px;
  padding: 3px;
  margin: 0px;
}

.card-header {
  font-size: 12px;
  padding: 7px;
  margin: 0px;
  min-height: 143px;
}

.tabs {
  margin: 0px;
  min-height: 143px;
}

.btn_power {
  width: 35px;
  height: 35px;
  background: url(../assets/images/ico_power.png) no-repeat 0 0;
  background-size: 100%;
  text-indent: -9999em;
  border: 0px;
  margin-left: 20px;
  margin-right: 25px;
}

.off {
  opacity: 0.2 !important;
}

.row {
  flex-wrap: nowrap;
}

.main_panel .status_panel {
  width: 100%;
  margin: 0 auto;
  height: 185px;
  padding: 0 2% 15px 2%;
}

.status_air_conditioner {
  width: 100%;
  height: 50px;
}

.degree_air_conditioner {
  width: 110px;
  float: left;
}

.degree_air_conditioner strong.num_degree {
  font-family: LCD-Bold;
  color: #3f3f3f;
  font-size: 2.2rem;
  display: inline-block;
  vertical-align: top;
  position: relative;
  top: -8px;
  left: -8px;
}

.status_washer.status {
  width: 100%;
  height: 28px;
  padding-left: 113px;
}

.wawher_adjust {
  display: inline-block;
  width: 39px;
  position: relative;
  top: 6px;
  left: -8px;
}

.num_washer {
  font-family: LCD-Bold;
  color: #3f3f3f;
  font-size: 1.8rem;
  display: inline-block;
  vertical-align: top;
  position: relative;
  top: -8px;
  left: -8px;
}

.degree_unit {
  display: inline-block;
  width: 21px;
  height: 41px;
  text-indent: -9999em;
  background: url(../assets/images/ico_degree_c_check.png) no-repeat 0 0;
  position: relative;
  top: -19px;
}

.degree_adjust {
  display: inline-block;
  width: 39px;
  position: relative;
  top: 0px;
}

button.btn_degree_up {
  width: 20px;
  height: 20px;
  background: url(../assets/images/ico_degree_up.png) no-repeat 0 0;
  background-size: 100%;
  text-indent: -9999em;
  border: 0px solid transparent;
}

button.btn_degree_down {
  width: 20px;
  height: 20px;
  background: url(../assets/images/ico_degree_down.png) no-repeat 0 0;
  background-size: 100%;
  text-indent: -9999em;
  border: 0px solid transparent;
}

button.btn_course_start {
  width: 20px;
  height: 20px;
  background: url(../assets/images/ico_start.png) no-repeat 0 0;
  background-size: 100%;
  text-indent: -9999em;
  border: 0px solid transparent;
}

select.select_simulator {
  font-size: 12px;
  line-height: 1em;
  width: 100px;
  height: 22px;
  border-radius: 2px;
}

ol,
ul,
li {
  list-style: none;
  padding: 0px;
  margin: 0px;
}

.prop_lists {
  display: inline-block;
  width: 220px;
  text-align: left;
}

.form_area {
  display: inline-block;
  text-align: left;
  width: 58%;
  height: 23px;
}

.prop_name {
  display: inline-block;
  width: 70px;
  color: #3f3f3f;
  font-size: 0.8rem;
  font-family: "Arial";
  font-weight: bold;
  text-align: left;
}

.set_left_bottom_panel.air_conditioner {
  float: left;
}
</style>
