# Copyright 2018 Amazon.com, Inc. or its affiliates. All Rights Reserved.
# PDX-License-Identifier: MIT-0 (For details, see https://github.com/awsdocs/amazon-rekognition-developer-guide/blob/master/LICENSE-SAMPLECODE.)
from io import BytesIO
import boto3

import requests


def recognize_celebrities(url):
    # TODO set AWS credential
    client = boto3.client(
        'rekognition',
        aws_access_key_id="********************",
        aws_secret_access_key="**********************",
        aws_session_token="************************************"
    )

    img_res = requests.get(url)
    response = client.recognize_celebrities(Image={'Bytes': BytesIO(img_res.content).read()})
    celeb_info = []
    for celebrity in response['CelebrityFaces']:
        celeb = {
            "id": celebrity['Id'],
            "name": celebrity['Name'],
            "position": celebrity['Face']['BoundingBox'],
            "info": celebrity['Urls']
        }
        celeb_info.append(celeb)
    return celeb_info
