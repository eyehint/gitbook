var port = "8012"
var selectedIp = null;
var celeb_position = {}

function get_tv_list() {
    var tv_list = "";
    $.ajax({
        url: "http://localhost:" + port + "/list",
        processData: false,
        type: 'GET',
        contentType: 'application/json',
        success: function (data) {
            for(var ip in data) {
                tv_list += '<tr>';
                tv_list += '<td>' + ip + '</td>';
                tv_list += '<td>' + decodeURI(data[ip]) + '</td>';
                tv_list += '<td><button class="connect-tv" id="btn_' + ip + '" onclick="connect_tv(\'' + ip + '\')">연결</button></td>';
                tv_list += '</tr>';
            }
            $("#tv-list-body").append(tv_list);
        }
    });
}

function connect_tv(ip) {
    $('.connect-tv').prop('disabled', true);
    selectedIp = ip
    $.ajax({
        url: "http://localhost:" + port + "/connect/" + ip,
        processData: false,
        type: 'GET',
        contentType: 'application/json',
        success: function (data) {
            $('.connect-tv').prop('disabled', false);
            // Popup 끄기
            var modal = document.getElementById("myModal");
            modal.style.display = "none";
            // Toast
            var x = document.getElementById("snackbar_connected");
            x.className = "show";
            setTimeout(function(){ x.className = x.className.replace("show", ""); }, 3000);
        }
    });
}


function find_celeb_from_capture() {
    var ip = selectedIp;
    if(ip === null) {
        var x = document.getElementById("snackbar_error");
        x.className = "show";
        setTimeout(function(){ x.className = x.className.replace("show", ""); }, 3000);
    } else {
        $.ajax({
            url: "http://localhost:" + port + "/capture/" + ip + "/celeb",
            processData: false,
            type: 'GET',
            contentType: 'application/json',
            success: function (data) {
                draw_info(data)
            }
        });
    }
}


function draw_info(faceInfo) {
    var canvas = document.getElementById('canvas');
    if (canvas.getContext) {
        celeb_position = {}
        var ctx = canvas.getContext('2d');
        var imageObj = new Image();
        imageObj.onload = function () {
            canvas.width =  window.innerWidth;
            canvas.height = window.innerHeight;
            ctx.drawImage(imageObj, window.innerWidth/8, window.innerHeight/8, (window.innerWidth/8)*6, (imageObj.height*((window.innerWidth/8)*6))/imageObj.width);
            $.each(faceInfo.celeb_info, function(key, item){
                var x = window.innerWidth/8 + (window.innerWidth/8)*6*item.position.Left;
                var y = window.innerHeight/8 + ((imageObj.height*((window.innerWidth/8)*6))/imageObj.width)*item.position.Top;
                var w = ((window.innerWidth/8)*6)*item.position.Width;
                var h = ((imageObj.height*((window.innerWidth/8)*6))/imageObj.width)*item.position.Height;

                celeb_position[item.name] = {
                    x: x,
                    y: y,
                    w: w,
                    h: h,
                    info: item.info
                }
                ctx.strokeStyle = 'red';
                ctx.lineWidth = 3;
                ctx.strokeRect(x, y, w, h);

                // Text 처리
                ctx.textBaseline = 'top';
                ctx.font="30px Verdana";
                ctx.fillStyle = "white";
                ctx.fillText(item.name, x, y + w);
                ctx.fill();
            });
        }
        imageObj.src = faceInfo.imageUri;
    }

}
document.addEventListener("DOMContentLoaded", function() {
    get_tv_list();
    var canvas = document.getElementById('canvas');
    canvas.addEventListener('click', handle_canvas_click_event)
    function handle_canvas_click_event(event) {
        for(var name in celeb_position){
            var position = celeb_position[name];
            if(position.x <= event.pageX && position.x + position.w >= event.pageX) {
                if(position.y <= event.pageY && position.y + position.h >= event.pageY) {
                    if(celeb_position[name].info.length > 0) {
                        window.open("https://" + celeb_position[name].info[0], '_blank');
                    } else {
                        window.open("https://www.google.com/search?q=" + name, '_blank');
                    }
                }
            }

        }
    }
});