import requests

from flask import Flask, render_template
from flask_cors import CORS
from image.celebrities_recognizer import recognize_celebrities

app = Flask(__name__)
CORS(app)

HOST = "http://127.0.0.1:5011"


@app.route('/')
def controller():
    return render_template("index.html")


@app.route('/list', methods=('GET', ))
def list_tv():
    path = f"/webostv"
    headers = _create_headers()
    response = requests.get(HOST + path, headers=headers).json()
    return response


@app.route('/connect/<ip>', methods=('GET', ))
def connect_tv(ip):
    path = f"/webostv/{ip}"
    headers = _create_headers()
    response = requests.post(HOST + path, headers=headers).json()
    return response


@app.route('/capture/<ip>', methods=('GET', ))
def capture(ip):
    path = f"/webostv/{ip}/control/capture"
    headers = _create_headers()
    response = requests.get(HOST + path, headers=headers).json()
    return response


@app.route('/capture/<ip>/celeb', methods=('GET',))
def find_celeb_from_capture(ip):
    response = capture(ip)
    url = response['imageUri']
    celeb_info = recognize_celebrities(url)
    search_response = response
    search_response['celeb_info'] = celeb_info
    return search_response


def _create_headers():
    headers = {
        "Content-Type": "application/json;charset=UTF-8"
    }
    return headers


if __name__ == '__main__':
    app.run(host="0.0.0.0", port=8012)
