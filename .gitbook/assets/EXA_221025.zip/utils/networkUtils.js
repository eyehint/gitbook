import { Api } from "libs";

const sendControlSync = async (deviceId, body) => {
  try {
    let res = await Api.damda.controlDAMDA(deviceId, body);
    console.log("controlSync", res);
    if (res.resultCode === "0000") {
      return res;
    } else {
      console.log("network error");
    }
  } catch (err) {
    console.log(err);
    return false;
  }
};

export { sendControlSync };
