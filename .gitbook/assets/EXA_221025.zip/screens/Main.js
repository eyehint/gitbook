import {
  AppBar,
  Text,
  ToolBar,
  ListDescription,
  FlexBox,
  Button,
} from "components";
import { Account, MonitoringFactory, State, useParams } from "libs";
import React, { useState, useEffect, useCallback } from "react";
import styled from "styled-components";
import { sendControlSync } from "../utils/networkUtils";

const TextBoxStyle = styled(FlexBox)`
  width: 100%;
  box-sizing: border-box;
  padding: 8px 24px;
  flex-shrink: 0 !important;
  > * {
    width: 100%;
  }
`;

const MainContainer = styled.div`
  height: 20vh;
  display: flex;
  justify-content: center;
  align-items: center;
  padding: 10px;
  margin: 10px;
`;

const commandBody = {
  CMD_LED_ON: {
    ctrlKey: "component",
    componentId: "com.hyein1.lee.sample.control_app",
    command: "ledon",
    dataSetList: {},
  },
  CMD_LED_OFF: {
    ctrlKey: "component",
    componentId: "com.hyein1.lee.sample.control_app",
    command: "ledoff",
    dataSetList: {},
  },
};

const Main = () => {
  const { productId } = useParams();
  const [watchProduct, setWatchProduct] = useState();
  const [watcherData, setWatcherData] = useState("");
  const [alias, setAlias] = useState("");

  console.log(`parameter productId : ${productId}`);
  const getProductAlias = (deviceId) => {
    return Account.getProductById(deviceId).alias;
  };

  const successCallback = useCallback((data) => {
    let productAlias = `Product Alias : ${getProductAlias(data.deviceId)}<br/>`;
    let jsonTxt =
      productAlias + JSON.stringify(data, null, 2).replaceAll(" ", "&nbsp;");
    setWatcherData(jsonTxt);
    console.log("Success callback");
    console.log(data);
  }, []);

  const failCallback = useCallback((data) => {
    console.log("Fail callback");
    console.log(data);
  }, []);

  function ledOn() {
    sendControlSync(productId, commandBody.CMD_LED_ON)
      .then((response) => {
        console.log(response);
      })
      .catch((error) => {
        console.log("Fail to send cts." + error);
      });
  }
  function ledOff() {
    sendControlSync(productId, commandBody.CMD_LED_OFF)
      .then((response) => {
        console.log(response);
      })
      .catch((error) => {
        console.log("Fail to send cts." + error);
      });
  }

  useEffect(() => {
    if (productId !== "null") {
      const product = Account.getProductById(productId);
      if (watchProduct === undefined) {
        if (product.type.toString() === "9001") {
          const item = {};
          item.product = JSON.parse(JSON.stringify(product));
          let monitoring = MonitoringFactory(
            item.product,
            successCallback,
            failCallback
          );
          item.monitoring = monitoring;
          console.log(`monitoring watcher start: ${item.product.id}`);
          monitoring.startMonitoring();
          setWatchProduct(item);
          setAlias(item.product.alias);
        }
      }
    }
    return () => {
      if (productId) {
        if (watchProduct !== undefined) {
          const monitoring = watchProduct.monitoring;
          console.log(`monitoring watcher stop: ${watchProduct.product.id}`);
          monitoring.stopMonitoring();
        }
      }
    };
  }, [watchProduct, successCallback, failCallback]);
  return (
    <>
      <AppBar divider="under">
        <ToolBar title="Main Scrren" navUp onNavUp={State.back}></ToolBar>
      </AppBar>
      <MainContainer>
        <Button color="rgba(17, 17, 17, 1)" onClick={ledOn}>
          LED On
        </Button>
        <Button color="rgba(17, 17, 17, 1)" onClick={ledOff}>
          LED Off
        </Button>
      </MainContainer>
      <ListDescription>
        <Text type="span" textCode="Type_A08" color="blue">
          "{alias}"
        </Text>
        <Text type="span" textCode="Type_A08">
          제품에 대하여 모니터링 결과를 보실 수 있습니다.
        </Text>
      </ListDescription>
      <TextBoxStyle>
        <Text textCode="Type_A08">{watcherData}</Text>
      </TextBoxStyle>
    </>
  );
};

export default Main;
