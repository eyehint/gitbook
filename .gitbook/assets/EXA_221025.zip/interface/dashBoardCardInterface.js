import { Account, getLocalImage } from "libs";

const getDashBoardCardData = (subcategory) => {
  return new Promise((resolve) => {
    console.log(subcategory);
    let cardTemplateData;
    if (subcategory === "EXA_DashboardCard_001") {
      const products = Account.getProductList();
      let cardProduct = undefined;
      for(let i=0; i<products.length; i++) {
        if (products[i].id === "260a296f-686b-47fe-82ad-928eef380ad7") { // DAMDA 제품2
          cardProduct = products[i];
          break;
        }
      }
      if (cardProduct !== undefined) {
        const snapshot = cardProduct.data.snapshot;
        console.log(snapshot);
        const link = `thinqapp://webapp?state=EXA_CEN01_Main&deviceId=${cardProduct.id}&modules=EXA&stateGoParams={}`;
        let image;
        let description1 = "연결 안  됨.";
        let description2 = "";
        if (snapshot.deviceState === 'E' && snapshot.online) {
          image = getLocalImage("EXA", process.env.REACT_APP_BUILD_TARGET, "images/icon/on.svg");
          description1 = `연결이 되었습니다.\n(${cardProduct.id})`;
        } else {
          image = getLocalImage("EXA", process.env.REACT_APP_BUILD_TARGET, "images/icon/off.svg");
          description1 = `연결이 되어 있지 않습니다!\n(${cardProduct.id})`;
        }
        cardTemplateData = {
          "type": "card_text_image",
          "templateVersion": "1.1",
          "link": link,
          "titleAreaWeight": 0.379999995231628,
          "bodyAreaWeight": 0.620000004768372,
          "title": cardProduct.alias,
          "description1": description1,
          "description2": description2,
          "image": image,
          "margin": -1,
          "topBottomMargin": -1
        };
      }
    } else if (subcategory === "EXA_DashboardCard_002") {
      cardTemplateData = {
        "type": "card_text_image",
        "templateVersion": "1.1",
        "titleAreaWeight": 0.0,
        "bodyAreaWeight": 100.0,
        "title": "2nd Card for EXA",
        "description1": "No problems were found with the product.",
        "description2": "Check the current status through smart diagnosis.",
        "actionTitle": "Diagnosis result",
        "image": "https://kic-qa-hdss-obj.lgthinq.com/caresds/icons/ic_care_smart_normal.svg",
        "margin": -1,
        "topBottomMargin": -1
      };
    }
    resolve(cardTemplateData);
  });
};

export { getDashBoardCardData };
