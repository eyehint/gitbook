import { State } from "libs/state";
import MainScreen from "./screens/Main";

const routes = State.route(
  [
    {
      path: "EXA",
      exact: true,
    },
    {
      path: "EXA_CEN01_Main",
      params: "/:productId",
      exact: true,
      component: MainScreen,
    },
  ],
  "EXA"
);

export default () => {
  return State.renderRoutes(routes);
};

export * from "./interface";