import Vue from "vue"
import Vuex from "vuex"

Vue.use(Vuex)

export default new Vuex.Store({
    state: {
        errorState: "",
        isAuth: false
    },
    mutations: {
        setAuth(state, isAuth) {
            state.isAuth = isAuth
        }
    },
    getters: {
        getErrorState: state => state.errorState,
        getIsAuth: state => state.isAuth
    },
    actions: {
        setAuth(store, isAuth) {
            store.commit('setAuth', isAuth)
        }
    }
})
