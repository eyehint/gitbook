<template>
  <div id="app">
    <router-view></router-view>
  </div>
</template>
<script>
export default {
  name: "App",
  mounted() {
    document.cookie = "same-site-cookie=foo; SameSite=Lax"
    document.cookie = "cross-site-cookie=bar; SameSite=None; Secure"
  }
}
</script>
<style>
@font-face {
  font-family: LCD-Bold;
  src: url("./assets/fonts/LCD-Bold.woff") format("woff");
}

#app {
  font-family: "Avenir", Helvetica, Arial, sans-serif;
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale;
  text-align: center;
  color: #2c3e50;
  margin-top: 3px;
}
</style>
