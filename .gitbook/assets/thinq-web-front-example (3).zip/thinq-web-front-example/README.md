# thinq-web-example

## Project setup
```
npm install
```

### Compiles and hot-reloads for development
```
npm run serve
```

### Compiles and minifies for production
```
npm run build
```

## Information for Server
### For public component test
1. com.damda.public.thinq-backend-api (public component)
    * http://localhost:5010
    * ws://localhost:5010
### For server test
1. damda-emp-thinq-proxy
    * https://i35uinebbb.execute-api.ap-northeast-2.amazonaws.com
    * 개발 정보 collab: http://collab.lge.com/main/display/TIP/damda.admin.emp-thinq-proxy?src=contextnavpagetreemode)
2. callback server
    * wss://s7vajyybvf.execute-api.ap-northeast-2.amazonaws.com/websocket
